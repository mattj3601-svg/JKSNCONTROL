@echo off
title SouthOps V4 - Install
npm install
pause
