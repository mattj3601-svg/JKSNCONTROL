@echo off
title SouthOps V4
node index.js
pause
